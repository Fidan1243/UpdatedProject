﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication.Business.Abstract;

namespace WebApplication.Business.Concrete
{
    public class FriendManager : IFriendService
    {
        public void AddFriend(string UserId)
        {
            throw new NotImplementedException();
        }

        public void GetFriends(string Id)
        {
            throw new NotImplementedException();
        }

        public void RemoveFriend(string UserId)
        {
            throw new NotImplementedException();
        }
    }
}
