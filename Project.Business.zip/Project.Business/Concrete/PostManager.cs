﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication.Business.Abstract;

namespace WebApplication.Business.Concrete
{
    public class PostManager : IPostService
    {
        public void Add(Post post)
        {
            throw new NotImplementedException();
        }

        public void Delete(Post post)
        {
            throw new NotImplementedException();
        }

        public List<Post> GetAll()
        {
            throw new NotImplementedException();
        }

        public List<Post> GetByCategory(string categoryId)
        {
            throw new NotImplementedException();
        }

        public Post GetById(string id)
        {
            throw new NotImplementedException();
        }

        public List<Post> GetByUser(string userId)
        {
            throw new NotImplementedException();
        }

        public void Update(Post post)
        {
            throw new NotImplementedException();
        }
    }
}
