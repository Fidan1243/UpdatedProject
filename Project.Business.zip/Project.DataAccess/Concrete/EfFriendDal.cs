﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication.Core.DataAccess.EntityFramework;
using WebApplication.DataAccess.Abstract;
using WebApplication.Entities.Concrete;

namespace WebApplication.DataAccess.Concrete
{
    public class EfFriendDal: EfEntityRepositoryBase<Friend, ProjectContext>, IFriendDal
    {
    }
}
