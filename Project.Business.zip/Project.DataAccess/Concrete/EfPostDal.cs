﻿using WebApplication.Core.DataAccess.EntityFramework;
using WebApplication.DataAccess.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication.DataAccess.Abstract;
using WebApplication.Entities.Concrete;

namespace WebApplication.DataAccess.Concrete
{
    public class EfPostDal: EfEntityRepositoryBase<Post, ProjectContext>, IPostDal
    {
    }
}
