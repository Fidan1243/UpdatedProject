﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication.Core.Entities
{
   public interface IEntity
    {
    }
}
